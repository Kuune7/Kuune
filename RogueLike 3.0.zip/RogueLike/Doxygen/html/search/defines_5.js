var searchData=
[
  ['player_5fdefault_5fdamage',['PLAYER_DEFAULT_DAMAGE',['../perso_8h.html#a54a62144e38aa9ec7b3cd5b06d9dd8a9',1,'perso.h']]],
  ['player_5fdefault_5fhealth',['PLAYER_DEFAULT_HEALTH',['../perso_8h.html#a750cae3714dcd2e1f482b72131cfd9e2',1,'perso.h']]]
];
