var searchData=
[
  ['fps',['fps',['../roguelike_8c.html#a45b67662d620a977a2cfe519f7ab6273',1,'roguelike.c']]]
];
