#include "monstre.h"
#include <sys/timeb.h>
#include <time.h>
#include <math.h>
#include <stdlib.h>



void AfficherMob(SDL_Renderer * rendu, Monstre mob) {

	SDL_SetRenderDrawColor (rendu, mob.r, mob.g, mob.b, 255);

	SDL_Rect monstre = {mob.salleX, mob.salleY, mob.tailleX, mob.tailleY};
	SDL_RenderFillRect(rendu, &monstre);

}

void InitMob(Monstre * mob, Salle salle, Player player, int tailleX, int tailleY, int hp, int maxDamage, int minDamage) {
	mob->tailleX = tailleX;
	mob->tailleY = tailleY;
	do {
		mob->salleX = rand()%(TAILLE_SALLE_X*TAILLE_TILE);
		mob->salleY = rand()%(TAILLE_SALLE_Y*TAILLE_TILE);
	} while ((salle.matTexture[mob->salleY/TAILLE_TILE][mob->salleX/TAILLE_TILE].mur == 1) || (salle.matTexture[(mob->salleY+mob->tailleY)/TAILLE_TILE][(mob->salleX+mob->tailleX)/TAILLE_TILE].mur == 1) || CollisionMob(player,mob));

	mob->r = rand()%255;
	mob->g = rand()%255;
	mob->b = rand()%255;

	mob->hp = mob->hp_max = hp;
	mob->vitesse = 1;

	mob->damages = rand()%maxDamage + minDamage;

	ftime(&mob->lastAttack);

}


int TimerMob(Monstre * mob) {

	int delay = 1000;

	struct timeb currentAttack;
	ftime(&currentAttack);
	int secondes = (int) difftime(currentAttack.time, mob->lastAttack.time);
	int ms1 = delay - mob->lastAttack.millitm;
    int ms2 = currentAttack.millitm;

	if ((((ms1+ms2) >= delay) && secondes >= 1) || (secondes >= 2)) {
		ftime(&mob->lastAttack);
		return 1;
	}

	return 0;
}


float max (float x, float y) {
	if (x > y) 
		return x;
	return y;
}

void DeplacementMonstre(Monstre * mob, Player player, SDL_Renderer * rendu) {

	/*int mobX = mob->salleX+(mob->tailleX/2), mobY = mob->salleY+(mob->tailleY/2);
	int playerX = player.salleX+(TAILLE_TILE/2), playerY = player.salleY+(TAILLE_TILE/2);
	

	float y = playerY - mobY;
	float x = playerX - mobX;
	float hypo = sqrt(x*x + y*y);

	x /= hypo;
	y /= hypo;

	mob->salleX += x;
	mob->salleY += y;*/


	float mobX = mob->salleX+(mob->tailleX/2), mobY = mob->salleY+(mob->tailleY/2);
	float playerX = player.salleX+(TAILLE_TILE/2), playerY = player.salleY+(TAILLE_TILE/2);

	int xincr, yincr;

	int dY = abs(playerY - mobY);
	int dX = abs(playerX - mobX);


	if (mobX < playerX)
		xincr = 1;
	else
		xincr = -1;
	
	if (mobY < playerY) 
		yincr = 1;
	else
		yincr = -1;

	int x = mobX;
	int y = mobY;

	SDL_Rect rect = {x, y, 5, 5};
	SDL_SetRenderDrawColor (rendu, 0, 255, 0, 255);

	int erreur;

	if (dX > dY) {
		erreur = dX/2;
		for (int i = 0 ; i < dX ; i++) {
			x += xincr;
			erreur += dY;
			if (erreur > dX) {
				erreur -= dX;
				y += yincr;
			}
			rect.x = x;
			rect.y = y;
			SDL_RenderFillRect(rendu, &rect);
		}
	}
	else {
		erreur = dY/2;
		for (int i = 0 ; i < dY ; i++) {
			y += yincr;
			erreur += dX;
			if (erreur > dY) {
				erreur -= dY;
				x += xincr;
			}
			rect.x = x;
			rect.y = y;
			SDL_RenderFillRect(rendu, &rect);
		}
	}
	
}