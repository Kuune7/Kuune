#include "const.h"

/**
 * \file const.c
 * \brief Fichier contenant des fonctions qui nous seront utile dans tout les domaines
 * \author HENRY Allan, STER Maxime, GAINSE Maxime, ZHENG Haoran
 * \version 0.1
 * \date 04/02/2020
*/


/**
 *	\brief Fonction permettant de savoir les coordonnées x et y se trouve bien dans le labyrinthe 
 *	\return Vrai ou Faux
 */
int valide (int x, int y) {
	return ((x >= 0 && x < M) && (y >= 0 && y < N));
}


/**
 *	\brief Fonction permettant de savoir les coordonnées x et y se trouve bien dans la salle 
 *	\return Vrai ou Faux
 */
int valideSalle (int x, int y) {
	return ((x >= 0 && x < LARGEUR_ECRAN-TAILLE_TILE) && (y >= 0 && y < HAUTEUR_ECRAN-TAILLE_TILE));
}
