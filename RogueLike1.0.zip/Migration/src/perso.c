#include "perso.h"
#include "menu.h"
#include "saveload.h"
#include <unistd.h>
#include <time.h>


/**
 * \file perso.c
 * \brief Fichier contenant des fonctions nous permettant de gérer la création, la modification et l'affichage du joueur
 * \author HENRY Allan, STER Maxime, GAINSE Maxime, ZHENG Haoran
 * \version 0.2
 * \date 04/02/2020
*/




/**
	\brief Permet de gérer l'évènement "attaquer"
*/
void AttaquePlayer (SDL_Renderer * rendu, Player * player) {

	SDL_SetRenderDrawBlendMode(rendu, SDL_BLENDMODE_BLEND);

	SDL_SetRenderDrawColor (rendu, 255, 100, 255, 100);

	SDL_Rect rect = {0, 0, TAILLE_TILE, TAILLE_TILE};

	for (int i = -1 ; i < 2 ; i++) {
		rect.y = i * TAILLE_TILE + player->salleY;
		for (int j = -1 ; j < 2 ; j++) {
			if (i || j) {
				rect.x = j * TAILLE_TILE + player->salleX;
				SDL_RenderFillRect(rendu, &rect);
			}
		}
	}

}


/**
	\brief Permet de gerer le mouvement du personnage dans une salle
*/
void ActionSalle(Input * in, SDL_Renderer * rendu, TTF_Font * police, Player * player, Salle salle, int * inGame, int * inMenu, Menu * menuActuel, Player playerSave, Salle salleSave[N][M], Labyrinthe labyrinthe) {

	int vitesse = 2;

	if (in->key[SDLK_ESCAPE]) {
		int menuIG = 1;
		MenuIG actuel = Premier;
		MenuIG choix;
		AfficherMenuIG(rendu,police);
		while (menuIG) {
			choix = choixMenuIG(rendu,police,actuel);
			switch (choix) {
				case Resume:
					menuIG = 0;
					break;
				case ReturnMenu:
					*inMenu = 1;
					*inGame = 0;
					*menuActuel = Principal;
					menuIG = 0;
					break;
				case Quitter:
					in->quit = 1;
					menuIG = 0;
					break;
				case Sauvegarde:
					AfficherMenuSauvegardeIG(rendu,police);
					actuel = Sauvegarde;
					break;
				case Sauvegarde1:
					SauvegarderPartie("./saves/Save1.txt", labyrinthe, playerSave, salleSave);
					AfficherSalle(rendu, salleSave[player->labY][player->labX], playerSave);
					AfficherMinimap(rendu, salleSave, playerSave);
					AfficherHUD(rendu, playerSave);
					AfficherMenuIG(rendu,police);
					actuel = Premier;
					break;
				case Sauvegarde2:
					SauvegarderPartie("./saves/Save2.txt", labyrinthe, playerSave, salleSave);
					AfficherSalle(rendu, salleSave[player->labY][player->labX], playerSave);
					AfficherPlayerSalle(rendu, player->salleX, player->salleY);
					AfficherMinimap(rendu, salleSave, playerSave);
					AfficherHUD(rendu, playerSave);
					AfficherMenuIG(rendu,police);
					actuel = Premier;
					break;
				case Sauvegarde3:
					SauvegarderPartie("./saves/Save3.txt", labyrinthe, playerSave, salleSave);
					AfficherSalle(rendu, salleSave[player->labY][player->labX], playerSave);
					AfficherPlayerSalle(rendu, player->salleX, player->salleY);
					AfficherMinimap(rendu, salleSave, playerSave);
					AfficherHUD(rendu, playerSave);
					AfficherMenuIG(rendu,police);
					actuel = Premier;
					break;
				case Premier:
					AfficherSalle(rendu, salleSave[player->labY][player->labX], playerSave);
					AfficherPlayerSalle(rendu, player->salleX, player->salleY);
					AfficherMinimap(rendu, salleSave, playerSave);
					AfficherHUD(rendu, playerSave);
					AfficherMenuIG(rendu,police);
					actuel = Premier;
					break;
				default:
					break;
			}
		}


		in->key[SDLK_ESCAPE] = 0;
		in->key[SDLK_z] = 0;
		in->key[SDLK_SPACE] = 0;
		in->key[SDLK_d] = 0;
		in->key[SDLK_q] = 0;
	}


	if (in->key[SDLK_z]) {
		if (valideSalle(player->salleX, player->salleY-vitesse) && !salle.matTexture[(player->salleY-vitesse)/TAILLE_TILE][player->salleX/TAILLE_TILE].mur)
			player->salleY -= vitesse;
	}
	if (in->key[SDLK_s]) {
		if (valideSalle(player->salleX, player->salleY+vitesse) && !salle.matTexture[(player->salleY)/TAILLE_TILE + 1][player->salleX/TAILLE_TILE].mur)
			player->salleY += vitesse;
	}
	if (in->key[SDLK_q]) {
		if (valideSalle(player->salleX-vitesse, player->salleY) && !salle.matTexture[player->salleY/TAILLE_TILE][(player->salleX-vitesse)/TAILLE_TILE].mur)
			player->salleX -= vitesse;
	}
	if (in->key[SDLK_d]) {
		if (valideSalle(player->salleX+vitesse, player->salleY) && !salle.matTexture[player->salleY/TAILLE_TILE][(player->salleX)/TAILLE_TILE + 1].mur)
			player->salleX += vitesse;
	}


	if (in->mousebuttons[SDL_BUTTON_LEFT]) {
		AttaquePlayer(rendu, player);
		SDL_RenderPresent(rendu);
		sleep(1);
	}
}



/**
    \brief Permet d'afficher la joueur sur la minimap à la position x - y
*/
void AfficherPlayerMinimap(SDL_Renderer * rendu, int x, int y, int px, int py) {

	SDL_SetRenderDrawBlendMode(rendu, SDL_BLENDMODE_BLEND);

	if (px > TAILLE_SALLE_X*TAILLE_TILE-7*TAILLE_TILE && py < 4*TAILLE_TILE) {
		SDL_SetRenderDrawColor (rendu, 0, 255, 255, 100);;
	}
	else {
		SDL_SetRenderDrawColor (rendu, 0, 255, 255, 255);
	}


	SDL_Rect player = {LARGEUR_ECRAN - LARGEUR_MINIMAP - 20 + x*TAILLE_CASE + TAILLE_CASE/4, 20 + y*TAILLE_CASE + TAILLE_CASE/4, TAILLE_CASE/2, TAILLE_CASE/2};
	SDL_RenderFillRect(rendu, &player);

}


/**
    \brief Permet d'afficher la joueur dans la salle à la position x - y
*/
void AfficherPlayerSalle(SDL_Renderer * rendu, int x, int y) {

	SDL_SetRenderDrawColor (rendu, 0, 255, 255, 255);

	SDL_Rect player = {x, y, TAILLE_TILE, TAILLE_TILE};
	SDL_RenderFillRect(rendu, &player);
}


/**
	\brief Fonction permettant à un joueur de passer d'une salle a une autre. Permet également de mettre à jour la minimap en ajoutant la salle comme explorer
*/
void PassagePorte(Salle salle[N][M], int * salleX, int * salleY, int * playerX, int * playerY) {

	int boxCollision = TAILLE_TILE;

	//Si il y a une porte a est
	if (salle[*salleY][*salleX].est == 1) {
		if ((*playerX >= LARGEUR_ECRAN-TAILLE_TILE-boxCollision) && (*playerX <= LARGEUR_ECRAN) && (*playerY >= HAUTEUR_ECRAN/2-2*TAILLE_TILE-boxCollision) && (*playerY <= ((HAUTEUR_ECRAN/2+2*TAILLE_TILE+boxCollision)))) {
			*salleX += 1;
			*playerX = 2*TAILLE_TILE;
			*playerY = HAUTEUR_ECRAN/2;
			salle[*salleY][*salleX].explorer = 1;
		}
	}

	//Si il y a une porte a ouest
	if (salle[*salleY][*salleX].ouest == 1) {
		if ((*playerX >= 0) && (*playerX <= TAILLE_TILE) && (*playerY >= (HAUTEUR_ECRAN/2-2*TAILLE_TILE-boxCollision)) && (*playerY <= (HAUTEUR_ECRAN/2+2*TAILLE_TILE))) {
			*salleX -= 1;
			*playerX = LARGEUR_ECRAN - 3*TAILLE_TILE;
			*playerY = HAUTEUR_ECRAN/2;
			salle[*salleY][*salleX].explorer = 1;
		}
	}

	//Si il y a une porte a sud
	if (salle[*salleY][*salleX].sud == 1) {
		if ((*playerY >= HAUTEUR_ECRAN-TAILLE_TILE-boxCollision) && (*playerY <= HAUTEUR_ECRAN) && (*playerX >= (LARGEUR_ECRAN/2-2*TAILLE_TILE)-boxCollision) && (*playerX <= (LARGEUR_ECRAN/2+2*TAILLE_TILE)-1)) {
			*salleY += 1;
			*playerX = LARGEUR_ECRAN/2;
			*playerY = 2*TAILLE_TILE;
			salle[*salleY][*salleX].explorer = 1;
		}
	}

	//Si il y a une porte a nord
	if (salle[*salleY][*salleX].nord == 1) {
		if ((*playerY >= 0) && (*playerY <= TAILLE_TILE+1) && (*playerX >= (LARGEUR_ECRAN/2-2*TAILLE_TILE)-boxCollision) && (*playerX <= (LARGEUR_ECRAN/2+2*TAILLE_TILE)-1)) {
			*salleY -= 1;
			*playerX = LARGEUR_ECRAN/2;
			*playerY = HAUTEUR_ECRAN - 3*TAILLE_TILE;
			salle[*salleY][*salleX].explorer = 1;
		}
	}
}




/**
	\brief Permet d'afficher l'HUD (Head Up Display). Ceci permet au joueur d'avoir les informations les plus utiles à porter de main (comme par exemple sa barre de vie)
*/
void AfficherHUD (SDL_Renderer * rendu, Player player) {

	SDL_SetRenderDrawBlendMode(rendu, SDL_BLENDMODE_BLEND);

	float pourcentageVie = (float)player.hp/player.hp_max;
	if ((player.salleX < 7*TAILLE_TILE) && (player.salleY > TAILLE_SALLE_Y*TAILLE_TILE - 4*TAILLE_TILE) && (player.salleY < TAILLE_SALLE_Y*TAILLE_TILE)) {
		SDL_SetRenderDrawColor (rendu, 0, 0, 0, 100);
	}
	else {
		SDL_SetRenderDrawColor (rendu, 0, 0, 0, 255);
	}

	SDL_Rect hpBar = {20, HAUTEUR_ECRAN - 100, HP_BAR_X, HP_BAR_Y};

	SDL_RenderFillRect(rendu, &hpBar);

	if ((player.salleX < 7*TAILLE_TILE) && (player.salleY > TAILLE_SALLE_Y*TAILLE_TILE - 4*TAILLE_TILE) && (player.salleY < TAILLE_SALLE_Y*TAILLE_TILE)) {
		SDL_SetRenderDrawColor (rendu, 0, 255, 0, 100);
	}
	else {
		SDL_SetRenderDrawColor (rendu, 0, 255, 0, 255);
	}

	hpBar.w = HP_BAR_X * pourcentageVie;
	SDL_RenderFillRect(rendu, &hpBar);

}	


/**
	\brief Permet d'initialiser une structure player
*/
void initPlayer(Player * player, int labX, int labY, int salleX, int salleY) {
	player->damage = PLAYER_DEFAULT_DAMAGE;
	player->hp = PLAYER_DEFAULT_HEALTH;
	player->hp_max = PLAYER_DEFAULT_HEALTH;
	player->labX = labX;
	player->labY = labY;
	player->salleX = salleX;
	player->salleY = salleY;
}




int CollisionMob(Player player, Monstre * mob) {
	if ((player.salleX >= mob->salleX) && (player.salleX <= (mob->salleX+mob->tailleX)) && (player.salleY >= mob->salleY) && (player.salleY <= (mob->salleY+mob->tailleY)))
		return 1;
	else if (((player.salleX+TAILLE_TILE) >= mob->salleX) && ((player.salleX+TAILLE_TILE) <= (mob->salleX+mob->tailleX)) && (player.salleY >= mob->salleY) && (player.salleY <= (mob->salleY+mob->tailleY)))
		return 1;
	else if ((player.salleX >= mob->salleX) && (player.salleX <= (mob->salleX+mob->tailleX)) && ((player.salleY+TAILLE_TILE) >= mob->salleY) && ((player.salleY+TAILLE_TILE) <= (mob->salleY+mob->tailleY)))
		return 1;
	else if (((player.salleX+TAILLE_TILE) >= mob->salleX) && ((player.salleX+TAILLE_TILE) <= (mob->salleX+mob->tailleX)) && ((player.salleY+TAILLE_TILE) >= mob->salleY) && ((player.salleY+TAILLE_TILE) <= (mob->salleY+mob->tailleY)))
		return 1;
	return 0;
}