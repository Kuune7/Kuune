#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <unistd.h>
#include <sys/timeb.h>
#include "labyrinthe.h"
#include "saveload.h"
#include "perso.h"
#include "monstre.h"

/**
 * \file roguelike.c
 * \brief Fichier contenant la fonction main de notre programme
 * \author HENRY Allan, STER Maxime, GAINSE Maxime, ZHENG Haoran
 * \version 0.1
 * \date 04/02/2020
*/

/** \brief Permet de savoir si le joueur est dans un menu ou non*/
int inGame = 0;
/** \brief Permet de savoir si le joueur est en partie ou non */
int inMenu = 1;

/** \brief Permet de savoir dans quel menu le joueur se trouve (si il est dans un menu)*/
Menu menuActuel = Principal;


int fps = 0;
int n = 0;
struct timeb lastFPS;

void AfficherFPS(SDL_Renderer * rendu, TTF_Font * police) {

	struct timeb currentFPS;

	char texteTab[5];

	SDL_Rect rect;
	SDL_Surface * texte;
	SDL_Color couleur = {94, 148, 0};

	rect.x = 5;
	rect.y = 5;

	ftime(&currentFPS);
	int secondes = (int) difftime(currentFPS.time, lastFPS.time);
	int ms1 = 1000 - lastFPS.millitm;
    int ms2 = currentFPS.millitm;

	fps++;

	if ((((ms1+ms2) >= 1000) && secondes >= 1) || (secondes >= 2)) {
		ftime(&lastFPS);
		n = fps;
		fps = 0;
	}

	sprintf(texteTab, "%d", n);
	texte = TTF_RenderText_Solid(police, texteTab, couleur);
	SDL_Texture * texture = SDL_CreateTextureFromSurface(rendu, texte);
	SDL_QueryTexture(texture, NULL, NULL, &rect.w, &rect.h);
	SDL_RenderCopy(rendu, texture, NULL, &rect);

	SDL_DestroyTexture(texture);
	SDL_FreeSurface(texte);

}


/**
 * \brief Fonction main du programme
 */
int main(int argc, char ** argv) {


	TTF_Init();
	SDL_Init(SDL_INIT_VIDEO);

	SDL_Window *screen = SDL_CreateWindow("RogueLike", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, LARGEUR_ECRAN, HAUTEUR_ECRAN, SDL_SWSURFACE);
	SDL_Renderer * rendu = SDL_CreateRenderer(screen, -1, 0);
	SDL_Surface * icon = SDL_LoadBMP("Icon.bmp");
	SDL_SetWindowIcon(screen, icon);
	SDL_FreeSurface(icon);


	TTF_Font * police = TTF_OpenFont("Font.ttf", 65);

	Salle salle[N][M];

	Input in;
	Player player;
	Monstre mob;

	Labyrinthe labyrinthe;


	//Initialisation nécessaire
	InitEvents(&in);
	ftime(&lastFPS);


	while (!in.quit) {

		while (inMenu && !in.quit) {

			Menu choix = choixMenu(menuActuel);

			switch (choix) {
				case Principal:
					menuActuel = Principal;
					AfficherMenuPrincipal(rendu, police);
					break;
				case New:
					inMenu = 0;
					inGame = 1;
					initLab(&labyrinthe);
					initSalle(salle, labyrinthe.mat);
					initPlayer(&player, 0, 0, LARGEUR_ECRAN/2 - TAILLE_TILE/2, HAUTEUR_ECRAN/2 - TAILLE_TILE/2);
					salle[player.labY][player.labY].explorer = 1;
					break;
				case Load:
					menuActuel = Load;
					AfficherMenuChargerPartie(rendu, police);
					break;
				case Quit:
					in.quit = 1;
					break;
				case Save1:
					inMenu = 0;
					inGame = 1;
					ChargerPartie("./saves/Save1.txt", &labyrinthe, &player, salle);
					ChargerLab(&labyrinthe);
					break;
				case Save2:
					inMenu = 0;
					inGame = 1;
					ChargerPartie("./saves/Save2.txt", &labyrinthe, &player, salle);
					ChargerLab(&labyrinthe);
					break;
				case Save3:
					inMenu = 0;
					inGame = 1;
					ChargerPartie("./saves/Save3.txt", &labyrinthe, &player, salle);
					ChargerLab(&labyrinthe);
					break;
				default:
					break;
			}
			SDL_RenderPresent(rendu);
			SDL_Delay(5);
		}

		InitMob(&mob, salle[player.labY][player.labX], player, TAILLE_TILE, TAILLE_TILE, 100, 30, 5);

		while (inGame && !in.quit) {
			
			UpdateEvents(&in);

			ActionSalle(&in, rendu, police, &player, salle[player.labY][player.labX], &inGame, &inMenu, &menuActuel, player, salle, labyrinthe);
			PassagePorte(salle, &player.labX, &player.labY, &player.salleX, &player.salleY);
			AfficherSalle(rendu, salle[player.labY][player.labX], player);
			AfficherMinimap(rendu, salle, player);
			AfficherHUD(rendu, player);
			AfficherFPS(rendu, police);
			AfficherMob(rendu, mob);

			DeplacementMonstre(&mob, player, rendu);

			if (CollisionMob(player, &mob)) {
				if (TimerMob(&mob)) {
					player.hp -= mob.damages;
					if (player.hp < 0) 
						player.hp = 0;
				}
			}

			SDL_RenderPresent(rendu);
			SDL_Delay(5);
		}
	}



	TTF_Quit();
	SDL_Quit();

	return 0;
}
