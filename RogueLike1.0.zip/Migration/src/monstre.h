#ifndef __MONSTRE__
#define __MONSTRE__

#include "const.h"
#include "perso.h"


void AfficherMob(SDL_Renderer * rendu, Monstre mob);
void InitMob(Monstre * mob, Salle salle, Player player, int tailleX, int tailleY, int hp, int maxDamage, int minDamage);
int TimerMob(Monstre * mob);
void DeplacementMonstre(Monstre * mob, Player player, SDL_Renderer * rendu);

#endif