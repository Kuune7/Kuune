#include "salle.h"


/**
 * \file salle.c
 * \brief Fichier contenant des fonctions nous permettant de gérer la création et l'affichage des salles
 * \author HENRY Allan, STER Maxime, GAINSE Maxime, ZHENG Haoran
 * \version 0.1
 * \date 04/02/2020
*/


/**
	\brief Permet d'initialiser la matrice de type Salle. Si le lieu est un couloir : On vas enregister où se trouve les couloirs à proximité puis indiquer les directions des portes. Si le lieu est un mur : On initialise tout à 0
*/
void initSalle(Salle salle[N][M], int mat[N][M]) {


	for (int i = 0 ; i < N ; i++) {
		for (int j = 0 ; j < M ; j++) {
			salle[i][j].nbPorte = 0;
			salle[i][j].est = 0;
			salle[i][j].sud = 0;
			salle[i][j].nord = 0;
			salle[i][j].ouest = 0;
			salle[i][j].explorer = 0;


			for (int k = 0 ; k < TAILLE_SALLE_Y ; k++) {
				for (int p = 0 ; p < TAILLE_SALLE_X ; p++) {
					if (p == 0 || k == 0 || k == (TAILLE_SALLE_Y-1) || p == (TAILLE_SALLE_X-1)) { // = Mur1
						salle[i][j].matTexture[k][p].id = 0;
						salle[i][j].matTexture[k][p].mur = 1;
						salle[i][j].matTexture[k][p].degats = 0;
					}
					else { // = Planche1
						salle[i][j].matTexture[k][p].id = 1;
						salle[i][j].matTexture[k][p].mur = 0;
						salle[i][j].matTexture[k][p].degats = 0;
					}
				}
			}

			if (mat[i][j] == COULOIR) { //C'est donc une salle

				//On compte le nombre de couloir a cote

				if (valide(j, i+1) && mat[i+1][j] == COULOIR) {
					salle[i][j].nbPorte++;
					salle[i][j].sud = 1;
				}
				if (valide(j, i-1) && mat[i-1][j] == COULOIR) {
					salle[i][j].nbPorte++;
					salle[i][j].nord = 1;
				}
				if (valide(j+1, i) && mat[i][j+1] == COULOIR) {
					salle[i][j].nbPorte++;
					salle[i][j].est = 1;
				}
				if (valide(j-1, i) && mat[i][j-1] == COULOIR) {
					salle[i][j].nbPorte++;
					salle[i][j].ouest = 1;
				}

			}
		}
	}
}


/** 
	\brief Permet d'afficher une salle (Zone principal de l'ecran)
*/
void AfficherSalle(SDL_Renderer * rendu, Salle salle, Player player) {

	SDL_Rect rectHori = {0, 0, 4*TAILLE_TILE, TAILLE_TILE};
	SDL_Rect rectVerti = {0, 0, TAILLE_TILE	, 4*TAILLE_TILE};

	//Fond

	SDL_Surface * mur1 = IMG_Load("./textures/mur1.png");
	SDL_Surface * planche1 = IMG_Load("./textures/planche1.png");

	SDL_Texture * T_planche1 = SDL_CreateTextureFromSurface(rendu, planche1);
	SDL_Texture * T_mur1 = SDL_CreateTextureFromSurface(rendu, mur1);


	SDL_Rect rect = {0, 0, TAILLE_TILE, TAILLE_TILE};

	for (int i = 0 ; i < TAILLE_SALLE_Y ; i++) {
		for (int j = 0 ; j < TAILLE_SALLE_X ; j++) {
			if (salle.matTexture[i][j].id == 0) { // = Mur1
				SDL_RenderCopy(rendu, T_mur1, NULL, &rect);
			}
			else if (salle.matTexture[i][j].id == 1) { // = Planche1
				SDL_RenderCopy(rendu, T_planche1, NULL, &rect);
			}
			rect.x += TAILLE_TILE;
		}
		rect.x = 0;
		rect.y += TAILLE_TILE;
	}

	SDL_DestroyTexture(T_planche1);
	SDL_DestroyTexture(T_mur1);


	SDL_FreeSurface(mur1);
	SDL_FreeSurface(planche1);


	SDL_SetRenderDrawColor (rendu, 102, 20, 20, 255);

	//On va regarder dans quel direction il y a une porte puis afficher les portes aux endroit prevu

	if (salle.sud) {
		rectHori.x = LARGEUR_ECRAN/2 - 2*TAILLE_TILE;
		rectHori.y = HAUTEUR_ECRAN - TAILLE_TILE;
		SDL_RenderFillRect(rendu, &rectHori);
	}

	if (salle.nord) {
		rectHori.x = LARGEUR_ECRAN/2 - 2*TAILLE_TILE;
		rectHori.y = 0;
		SDL_RenderFillRect(rendu, &rectHori);
	}

	if (salle.est) {
		rectVerti.x = LARGEUR_ECRAN - TAILLE_TILE;
		rectVerti.y = HAUTEUR_ECRAN/2 - 2*TAILLE_TILE;
		SDL_RenderFillRect(rendu, &rectVerti);
	}

	if (salle.ouest) {
		rectVerti.x = 0;
		rectVerti.y = HAUTEUR_ECRAN/2 - 2*TAILLE_TILE;
		SDL_RenderFillRect(rendu, &rectVerti);
	}

	AfficherPlayerSalle(rendu, player.salleX, player.salleY);

}
