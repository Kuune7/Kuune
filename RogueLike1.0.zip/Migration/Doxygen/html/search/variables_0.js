var searchData=
[
  ['damage',['damage',['../structPlayer.html#a433fa478597adbefe4ac3911c5639968',1,'Player']]]
];
