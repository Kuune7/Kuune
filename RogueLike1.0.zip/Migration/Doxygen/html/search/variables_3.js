var searchData=
[
  ['ingame',['inGame',['../roguelike_8c.html#a2ef448daa64dc4c81936a4836f21776c',1,'roguelike.c']]],
  ['inmenu',['inMenu',['../roguelike_8c.html#a69d26f73a3a33e36c53e39234b6a4ea4',1,'roguelike.c']]]
];
