var searchData=
[
  ['hp',['hp',['../structPlayer.html#a2baad6b9a274417a7374baf11d5f723d',1,'Player']]],
  ['hp_5fmax',['hp_max',['../structPlayer.html#aef9058c421fbf049050351a4652b5536',1,'Player']]]
];
