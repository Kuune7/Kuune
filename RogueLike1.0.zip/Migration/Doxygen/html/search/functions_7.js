var searchData=
[
  ['sauvegarderpartie',['SauvegarderPartie',['../saveload_8c.html#a3d0278632565de5c949641c16a477807',1,'SauvegarderPartie(const char name[30], Labyrinthe labyrinthe, Player player, Salle salle[N][M]):&#160;saveload.c'],['../saveload_8h.html#a3d0278632565de5c949641c16a477807',1,'SauvegarderPartie(const char name[30], Labyrinthe labyrinthe, Player player, Salle salle[N][M]):&#160;saveload.c']]]
];
