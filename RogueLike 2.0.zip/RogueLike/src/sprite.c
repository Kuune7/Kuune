#include "sprite.h"
#include <stdlib.h>


void LibererSprite (Sprite * sp) {
    free (sp);
}


Sprite * InitSprite(Animation * An, int x, int y) {
    Sprite * sp = malloc(sizeof(Sprite));
    sp->sens = 1;
    sp->stat = arret;
    sp->anim = An;
    sp->x = x;
    sp->y = y;
    return sp;
}

void MouvementSprite(Sprite * sp, Player player, Status stat) {

    sp->stat = stat;

    if (player.salleX < sp->x) { 
        sp->sens = 0;
    }
    else if (player.salleX > sp->y) {
        sp->sens = 1;
    }
    else { 
        sp->stat = arret;
    }

    sp->x = player.salleX;
    sp->y = player.salleY;
}