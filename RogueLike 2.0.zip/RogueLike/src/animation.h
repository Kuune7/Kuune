#ifndef __ANIMATION__
#define __ANIMATION__

#include "const.h"


typedef struct s_animUnique {
    int depart;
    int longeur;
    int temps;
} AnimUnique;


typedef struct s_animation {
    SDL_Surface * charset;
    AnimUnique ** tab;
    int largeurChar, hauteurChar;
    int nbXChar, nbYChar;
    int nbSens;
    int nbStats;
} Animation;

#endif