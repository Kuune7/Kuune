var searchData=
[
  ['hp',['hp',['../structMonstre.html#aa02914b052d2ca5194dffde9535050d1',1,'Monstre::hp()'],['../structPlayer.html#a2baad6b9a274417a7374baf11d5f723d',1,'Player::hp()']]],
  ['hp_5fmax',['hp_max',['../structMonstre.html#abea4d6613ce6e8bf8976d78aa8b660f8',1,'Monstre::hp_max()'],['../structPlayer.html#aef9058c421fbf049050351a4652b5536',1,'Player::hp_max()']]]
];
