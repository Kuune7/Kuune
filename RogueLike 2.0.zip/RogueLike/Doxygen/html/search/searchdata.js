var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuv",
  1: "ilmps",
  2: "cflmoprs",
  3: "acdeimpstuv",
  4: "abdefghilmnoprstv",
  5: "cio",
  6: "mp",
  7: "enos",
  8: "chlmnpt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Définitions de type",
  6: "Énumérations",
  7: "Valeurs énumérées",
  8: "Macros"
};

